app.controller('polishNotationCtrlr', ['$scope', 'polishNotationService', function($scope, polishNotationService) {	
	$scope.errorFlag = false;
	
	$scope.calculate = function() {
		arrResult = polishNotationService.polishNotationEvaluator($scope.postfixExp);
			
		if( arrResult.length > 1 || arrResult.length <=0 || isNaN(arrResult[0] ) ) {
			$scope.errorFlag = true;
			$scope.output = '';
            $scope.error = "Invalid value! Please check expression format.";
        } else {
			$scope.errorFlag = false;
			$scope.output = arrResult.pop();
	    }
		
	}    
}]);
