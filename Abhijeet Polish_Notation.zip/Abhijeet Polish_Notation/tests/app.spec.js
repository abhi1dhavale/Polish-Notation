describe('Testing Controller', function(){
	

    var $controller, $scope, controller;
	
	beforeEach(angular.mock.module('polishNotationModule'));
	
    beforeEach(inject(function(_$controller_){
		$controller = _$controller_;
    }));
	 
	beforeEach(function() {
      $scope = {};
      controller = $controller('polishNotationCtrlr', { $scope: $scope });
    });
	
	it('should return postfix evaluation 5 if the input expression is 2 3 +', function() {
      $scope.postfix = '2 3 +';
      $scope.calculate($scope.postfix);
      expect($scope.output).toEqual(5);
    });
	
	it('should return postfix evaluation 1 if the input expression is 3 4 -', function() {
      $scope.postfix = '3 4 -';
      $scope.calculate($scope.postfix);
      expect($scope.output).toEqual(1);
    });
	
	it('should return postfix evaluation 1 if the input expression is 10 7 -', function() {
      $scope.postfix = '10 7 -';
      $scope.calculate($scope.postfix);
      expect($scope.output).toEqual(-3);
    });
	
	it('should return postfix evaluation 12 if the input expression is 3 4 *', function() {
      $scope.postfix = '3 4 *';
      $scope.calculate($scope.postfix);
      expect($scope.output).toEqual(12);
    });
	
	it('should return output 1 if the input expression is 2 2 /', function() {
      $scope.postfix = '2 2 /';
	  $scope.calculate($scope.postfix);
      expect($scope.output).toEqual(1);	  
    });
	
	it('should return postfix evaluation 8 if the input expression is 2 3 ^', function() {
      $scope.postfix = '2 3 ^';
      $scope.calculate($scope.postfix);
      expect($scope.output).toEqual(8);
    });
	it('should return postfix evaluation 11 if the input expression is 2 3 + 4 4 * -', function() {
      $scope.postfix = '2 3 + 4 4 * -';
      $scope.calculate($scope.postfix);
      expect($scope.output).toEqual(11);
    });
	
	
	it('should return postfix evaluation 12 if the input expression is 10 3 %', function() {
      $scope.postfix = '10 3 %';
      $scope.calculate($scope.postfix);
      expect($scope.output).toEqual(1);
    });
	
	// error messages
	
	it('should return error message and blank output if the input expression is blank "" ', function() {
      $scope.postfix = '';
      $scope.calculate($scope.postfix);
	  expect($scope.error).toEqual("Please enter valid expression.");
      expect($scope.output).toEqual("");
    });
	
	it('should return error message and blank output if the input expression is e', function() {
      $scope.postfix = 'e';
      $scope.calculate($scope.postfix);
	  expect($scope.error).toEqual("Please check expression format.");
      expect($scope.output).toEqual("");
    });
	
	it('should return error message and blank output if the input expression is 2 4', function() {
      $scope.postfix = '2 4';
      $scope.calculate($scope.postfix);
	  expect($scope.error).toEqual("Please check expression format.");
      expect($scope.output).toEqual("");
    });
	
	it('should return error message and blank output if the input expression is 2 e', function() {
      $scope.postfix = '2 e';
      $scope.calculate($scope.postfix);
	  expect($scope.error).toEqual("Please check expression format.");
      expect($scope.output).toEqual("");
    });
	
	it('should return "Division by zero not allowed. Please enter valid number." if the input expression is "0 5 / " ', function() {
      $scope.postfix = '0 5 / ';
	  $scope.calculate($scope.postfix);
	  expect($scope.error).toEqual("Division by zero not allowed. Please enter valid number.");
      expect($scope.output).toEqual("");	 
    });
	
	it('should return error message and blank output if the input expression is 5 / * -', function() {
      $scope.postfix = '5 / * -';
      $scope.calculate($scope.postfix);
	  expect($scope.error).toEqual("Please check expression format.");
      expect($scope.output).toEqual("");
    });
	
	it('should return error message and blank output if the input expression is 2 4 $', function() {
      $scope.postfix = '2 4 $';
      $scope.calculate($scope.postfix);
	  expect($scope.error).toEqual("Please check expression format.");
      expect($scope.output).toEqual("");
    });
});