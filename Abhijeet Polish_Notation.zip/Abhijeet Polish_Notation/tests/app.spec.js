describe('Testing Controller', function(){
	

    var $controller, $scope, controller;
	
	beforeEach(angular.mock.module('polishNotationModule'));
	
    beforeEach(inject(function(_$controller_){
		$controller = _$controller_;
    }));
	 
	beforeEach(function() {
      $scope = {};
      controller = $controller('polishNotationCtrlr', { $scope: $scope });
    });
	
	it('should return postfix evaluation 5 if the input expression is 2 3 +', function() {
      $scope.postfix = '2 3 +';
      $scope.calculate($scope.postfix);
      expect($scope.output).toEqual(5);
    });
	it('should return postfix evaluation 8 if the input expression is 2 3 ^', function() {
      $scope.postfix = '2 3 ^';
      $scope.calculate($scope.postfix);
      expect($scope.output).toEqual(8);
    });
	it('should return postfix evaluation 11 if the input expression is 2 3 + 4 4 * -', function() {
      $scope.postfix = '2 3 + 4 4 * -';
      $scope.calculate($scope.postfix);
      expect($scope.output).toEqual(11);
    });
	it('should return postfix evaluation 1 if the input expression is 3 4 -', function() {
      $scope.postfix = '3 4 -';
      $scope.calculate($scope.postfix);
      expect($scope.output).toEqual(1);
    });
	it('should return postfix evaluation 12 if the input expression is 3 4 *', function() {
      $scope.postfix = '3 4 *';
      $scope.calculate($scope.postfix);
      expect($scope.output).toEqual(12);
    });
	it('should return error message and blank output if the input expression is 5 / * -', function() {
      $scope.postfix = '5 / * -';
      $scope.calculate($scope.postfix);
	  expect($scope.error).toEqual("Invalid value! Please check expression format.");
      expect($scope.output).toEqual("");
    });
});