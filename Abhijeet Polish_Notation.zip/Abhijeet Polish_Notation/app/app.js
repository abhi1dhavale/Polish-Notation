var app = angular.module('polishNotationModule', []);

app.controller('polishNotationCtrlr', ['$scope', function($scope) {	
	
	$scope.calculate = function(postfix){
		
		$scope.errorFlag = false;
		$scope.error	= '';		
		
		if( undefined == postfix ) {
			$scope.errorFlag = true;
			$scope.output = '';
			$scope.error = "Please enter valid expression.";
		} else {

			var arrResult = [];
			var arrExpression = postfix.split(" "); //splitting string based on spaces between characters.
					
			for( var i = 0; i < arrExpression.length; i++ ) {	
			
				if( !isNaN( arrExpression[i] ) ) {      
					arrResult.push( arrExpression[i] );
					
				} else { 
				
					var a = arrResult.pop();
					var b = arrResult.pop();
					var operator = arrExpression[i];
					
					switch(operator){
						case "+": 
							arrResult.push(parseInt(a) + parseInt(b));
							break;
						case "-":
							arrResult.push(parseInt(a) - parseInt(b));
							break;
						case "*":
							arrResult.push(parseInt(a) * parseInt(b));
							break;
						case "/":
							//division by 0 check
							if( parseFloat(b) === 0 ) {
								
								$scope.errorFlag = true;
								$scope.output = '';
								$scope.error = "Division by zero not allowed. Please enter valid number.";							
							} else {
								arrResult.push(parseInt(a) / parseInt(b));	
							}
							
							break;
						case "^":
							arrResult.push(Math.pow(parseInt(b), parseInt(a)));
							break;	
						case "%":
							arrResult.push((parseInt(b) % parseInt(a)));
							break;	
						default:
							$scope.errorFlag = true;
							$scope.output = '';
							$scope.error = "Please check expression format.";								
					}
				}
			}
			
			if( arrResult.length != 1 || isNaN(arrResult[0]) || isNaN( arrExpression[0] ) ) {
				$scope.errorFlag = true;
				$scope.output = '';
				if( '' == $scope.error ) {
					$scope.error = "Please check expression format.";
				}
			} else {
				$scope.errorFlag = false;
				$scope.output = arrResult.pop();
			}
		}
		
    }
	
}]);



